
import { GoogleGenAI } from "@google/genai";
import { Ratio } from "../types";

// Inicialización siguiendo las guías de @google/genai
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateInterpretation = async (ratio: Ratio): Promise<string> => {
    const prompt = `
        Eres un analista financiero experto en México.
        Genera una interpretación concisa y profesional en español (máximo 20 palabras) para un reporte de crédito.
        
        Ratio: "${ratio.name}"
        Valor Actual: ${ratio.value}
        Valor Año Anterior: ${ratio.previousValue}
        
        Ejemplo de respuesta: "La rentabilidad sobre patrimonio (ROE) creció 3.2 p.p. respecto al año anterior, indicando mejora en eficiencia del capital."
        
        Tu interpretación:
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });

        // El acceso a .text es directo como propiedad
        return response.text?.trim() || `Análisis estándar para ${ratio.name} completado.`;
    } catch (error) {
        console.error("Error generating interpretation:", error);
        return `Ratio ${ratio.name} dentro de rangos históricos operativos.`;
    }
};
